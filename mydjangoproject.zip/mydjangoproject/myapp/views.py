from django.shortcuts import render

# task views here.
def task_view(request):
    dynamic_data = "Hello from Django!"
    return render(request, 'task.html', {'dynamic_data': dynamic_data})
